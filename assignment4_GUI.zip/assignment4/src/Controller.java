
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.io.*;
import java.util.EventObject;
import java.util.Scanner;


public class Controller {
    @FXML
    private Label alarm_user;
    @FXML
    private Label confirm;
    @FXML
    private Label alarm_pass;
    @FXML
    private Label result;
    @FXML
    private TextField userId;
    @FXML
    private TextField Name;
    @FXML
    private TextField Family_Name;
    @FXML
    private TextField age;
    @FXML
    private TextField sabeqe;
    @FXML
    private TextField phone;
    @FXML
    private TextField username;
    @FXML
    private TextField password;
    @FXML
    private TextField pass;
    @FXML
    private TextField morakhaC;
    @FXML
    private TextField food;
    @FXML
    private Image event;
    @FXML
    private Image event2;

    public void login(){
        if (userId.getText().isEmpty()){
            alarm_user.setText("plz enter username");
        }
        if (pass.getText().isEmpty()){
            alarm_pass.setText("plz enter password");
        }else
        {
            Parent root2;
            try {
                root2 = FXMLLoader.load(getClass().getResource("loginSabt.FXML"));
                Stage stage2 = new Stage();
                stage2.setTitle("confirm information page");
                stage2.setScene(new Scene(root2, 430, 335));
                stage2.show();
                ((Node)(event2.getSource())).getScene().getWindow().hide();
            }
            catch (IOException e) {
                e.printStackTrace();
            }
        }



        /*log in from file*/

        //File filef = new File("src/file.txt");
        //PrintWriter output = new PrintWriter(new FileWriter(filef, true));
        //Scanner input = new Scanner(filef);
        //boolean found = false;
        //while(input.hasNextLine() && !found)
        //{
            //it has problem in loading information from file
            //if (userId.getText().equals("mosy") && pass.getText().equals("0021") )
            //{
                  // alarm_user.setText("Login successful !");
                    //found = true;
            //}
        //}
        /*if(!found)
        {
            alarm_user.setText("Login incorrect !");
        }*/
  /*String item = input.nextLine();
            String key = item.substring(0, item.indexOf(" : "));
            if(key.equals("username")){
                String value = item.substring(item.indexOf(" :  ") );
                System.out.println(value);
            }*/

        /*end login*/

    }

    public void sign() {
        Parent root;
        try {
            root = FXMLLoader.load(getClass().getResource("signIn.FXML"));
            Stage stage = new Stage();
            stage.setTitle("sign in page");
            stage.setScene(new Scene(root, 360, 545));
            stage.show();
            ((Node)(event.getSource())).getScene().getWindow().hide();
        }
        catch (IOException e) {
            e.printStackTrace();
        }


    }
    public void sabt() {
        if (Name.getText().isEmpty() || Family_Name.getText().isEmpty() || Family_Name.getText().isEmpty() || age.getText().isEmpty() || sabeqe.getText().isEmpty() || phone.getText().isEmpty() || username.getText().isEmpty() || password.getText().isEmpty()){
            result.setText("plz fill all inputs");
        }else{
            try {
                WriteFile writer = new WriteFile("src/file.txt" ,true);
                writer.WriteToFile("<");
                writer.WriteToFile("name :  " + Name.getText());
                writer.WriteToFile("family :  " + Family_Name.getText());
                writer.WriteToFile("age :  " + age.getText());
                writer.WriteToFile("sabeqe kari :  " + sabeqe.getText());
                writer.WriteToFile("enterd year :  " + phone.getText());
                writer.WriteToFile("username :  " + username.getText());
                writer.WriteToFile("password :  " + password.getText());
                writer.WriteToFile(">");
            }catch (IOException e){
                System.out.println(e.getMessage());
            }
            result.setText("all information saved\nnow you can close this window\nand sign in you account");
        }
    }

    public void sabtLog(){
        if (food.getText().isEmpty() || morakhaC.getText().isEmpty()){
            confirm.setText("plz fill all inputs");
        }else{
            try {
                WriteFile writer = new WriteFile("src/food_workers.txt" ,true);
                writer.WriteToFile("***********");
                writer.WriteToFile("username :  " + userId.getText());
                writer.WriteToFile("food :  " +  food.getText());
                writer.WriteToFile("***********");
            }catch (IOException e){
                System.out.println(e.getMessage());
            }
            confirm.setText("your food save in our System");
        }


    }
}

